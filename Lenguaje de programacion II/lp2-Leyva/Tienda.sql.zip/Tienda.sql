-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 17-05-2016 a las 22:53:44
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `Tienda`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `cliente`
-- 

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL auto_increment,
  `Apaterno` varchar(45) NOT NULL,
  `Amaterno` varchar(45) NOT NULL,
  `Nombre` varchar(45) NOT NULL,
  `Telefono` varchar(20) default NULL,
  `iddistrito` int(11) NOT NULL,
  PRIMARY KEY  (`idCliente`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- Volcar la base de datos para la tabla `cliente`
-- 

INSERT INTO `cliente` VALUES (1, 'Concepcion', 'Reyes', 'Páola Yessy', '977244962', 5);
INSERT INTO `cliente` VALUES (2, 'Trujillo', 'Rengifo', 'David Alejandro', '2593371', 5);
INSERT INTO `cliente` VALUES (4, 'Garay', 'Vasquez', 'Alberto', NULL, 6);
INSERT INTO `cliente` VALUES (5, 'Perez', 'Gomez', 'Julio', '2855239', 2);
INSERT INTO `cliente` VALUES (6, 'Goche', 'Borda', 'Consuelo', '12345678', 3);
INSERT INTO `cliente` VALUES (7, 'Ortiz', 'Perez', 'Raul', '2547789', 1);
INSERT INTO `cliente` VALUES (8, 'Linares ', 'Laime', 'Gianmarco', '947261184', 4);
INSERT INTO `cliente` VALUES (9, 'Ticona', 'Vilcapaza', 'Rodolfo', NULL, 2);
INSERT INTO `cliente` VALUES (10, 'Arias', 'Sarmiento', 'Daniel', '2648879', 1);
INSERT INTO `cliente` VALUES (11, 'Rengifo', 'Torres', 'Rosario', '97725698', 4);
INSERT INTO `cliente` VALUES (12, 'Paucar', 'Andamayo', 'Alessandro', '58769941', 3);
INSERT INTO `cliente` VALUES (13, 'Vega', 'De la Cruz', 'Alex', '2593345', 6);
INSERT INTO `cliente` VALUES (14, 'Condorchua', 'Laya', 'Alvaro', '4857796', 5);
INSERT INTO `cliente` VALUES (15, 'Egocheaga', 'Ossco', 'Jhonatan', NULL, 5);
INSERT INTO `cliente` VALUES (16, 'Rengifo', 'Torres', 'German', '2458874', 0);
INSERT INTO `cliente` VALUES (17, 'Rengifo ', 'Torres', 'Luz', '4587796', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `distrito`
-- 

CREATE TABLE `distrito` (
  `iddistrito` int(11) NOT NULL auto_increment,
  `Distrito` varchar(45) character set utf8 collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`iddistrito`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `distrito`
-- 

INSERT INTO `distrito` VALUES (1, 'San Juan de Miraflores');
INSERT INTO `distrito` VALUES (2, 'Villa Maria del Triunfo');
INSERT INTO `distrito` VALUES (3, 'Los Olivos');
INSERT INTO `distrito` VALUES (4, 'Magdalena');
INSERT INTO `distrito` VALUES (5, 'Villa el Salvador');
INSERT INTO `distrito` VALUES (6, 'Surco');
